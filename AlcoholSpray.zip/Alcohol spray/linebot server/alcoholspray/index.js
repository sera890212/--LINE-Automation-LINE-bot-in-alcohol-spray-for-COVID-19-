const linebot = require('linebot');
const express = require('express');
const bodyParser = require('body-parser');

var dat;
var data = "";
var msg1 = ['','alcohol is full.','alcohol is halfway full.','alcohol is almost empty.'];
var msg1ch = ['','很滿！','有一半！','快沒了！快去補充吧！'];
var msg2 = ['','is still there.','is still there.','is still there.'];
var msg2ch = ['','還在原地！','還在原地！','還在原地！'];
var msg3 = ['','battery is full.','battery is almost empty.','battery is almost empty.'];
var msg3ch = ['','不用充電！','快沒電了！','快沒電了！'];
var temp11; //Spray bottle 1 alcohol level message
var temp21; //Spray bottle 1 stolen message
var temp31; //Spray bottle 1 battery level message
var temp12; //Spray bottle 2 alcohol level message
var temp22; //Spray bottle 2 stolen message
var temp32; //Spray bottle 2 battery level message

const bot = linebot({
	channelId: process.env.CHANNEL_ID,
	channelSecret: process.env.CHANNEL_SECRET,
	channelAccessToken: process.env.CHANNEL_ACCESS_TOKEN
});

const app = express();

app.use(express.urlencoded())

const linebotParser = bot.parser();

app.get('/',function(req,res){
    res.send('Hello World!');
});

app.post('/linewebhook', linebotParser);

app.post('/alc', (req, res) => { //Recieve post request from arduino(Alcohol level)
    dat = req.body;
    console.log('id=', req.body.id,', data=', req.body.data);
    if(req.body.data==2) //2 = %50 alcohol level
    {
    	msg1[req.body.id] = " is halfway full.";
    	msg1ch[req.body.id] = " 還有一半！";
    }
    else if(req.body.data==1) //1 = 10% alcohol level
    {
    	msg1[req.body.id] = "alcohol is almost empty.";
    	msg1ch[req.body.id] = "快沒了！快去補充吧！";
		temp21 = '酒精' + req.body.id + "快沒了！快去補充吧！\n" + 'Spray '+ req.body.id + "alcohol is almost empty.";
		//bot.push('U3cc6dcce7decb7790441da95ec3ac164',temp21);
		bot.broadcast(temp21);
    }
    else
    {
    	msg1[req.body.id] = " is full.\n";
    }
});

app.post('/mov', (req, res) => { //Recieve post request from arduino(Movement)
	dat = req.body;
    console.log('id=', req.body.id,', data=', req.body.data);
    data = req.body.data;
	msg2[req.body.id] = "was moved!";
	msg2ch[req.body.id] = "被偷了！";
	temp21 = '酒精' + req.body.id + '被偷了！' + '\nSpray ' + req.body.id + ' was moved!';
	//bot.broadcast(temp21);
	//bot.push('U3cc6dcce7decb7790441da95ec3ac164',temp21);
	bot.broadcast(temp21);
});


bot.on('message', function (event) {
	switch (event.message.type) {
		case 'text':
			switch (event.message.text) {
				case '酒精液還夠嗎？Alcohol level？':
					temp12 = '酒精1'+msg1ch[1]+'\n-Spray 1 '+msg1[1]+'\n\n酒精2'+msg1ch[2]+'\n-Spray 2 '+msg1[2]+'\n\n酒精3'+msg1ch[3]+'\n-Spray 3 '+msg1[3];
					return event.reply(temp12);
					break;
				case '酒精瓶被偷了嗎？Stolen?':
					temp22 = '酒精1'+msg2ch[1]+'\n-Spray 1 '+msg2[1]+'\n\n酒精2'+msg2ch[2]+'\n-Spray 2 '+msg2[2]+'\n\n酒精3'+msg2ch[3]+'\n-Spray 3 '+msg2[3];
					return event.reply(temp22);
					break;

				case '行充還有電嗎？battery?':
					temp32 = '酒精1'+msg3ch[1]+'\n-Spray 1 '+msg3[1]+'\n\n酒精2'+msg3ch[2]+'\n-Spray 2 '+msg3[2]+'\n\n酒精3'+msg3ch[3]+'\n-Spray 3 '+msg3[3];
					return event.reply(temp32);
					break;
				case 'Me':
					event.source.profile().then(function (profile) {
						return event.reply('Hello ' + profile.displayName + ' ' + profile.userId);
					});
					break;
				case 'resetAlcohol1':
    				msg1[1] = " alcohol is full.";
    				msg1ch[1] = "很滿！";
					break;
				case 'resetAlcohol2':
    				msg1[2] = " battery is full.";
    				msg1ch[2] = "很滿！";
					break;
				case 'resetAlcohol3':
    				msg1[3] = " battery is full.";
    				msg1ch[3] = "很滿！";
					break;
				case 'resetBattery1':
    				msg3[1] = " battery is full.";
    				msg3ch[1] = "不用充電！";
					break;
				case 'resetBattery2':
    				msg3[2] = " battery is full.";
    				msg3ch[2] = "不用充電！";
					break;
				case 'resetBattery3':
    				msg3[3] = " battery is full.";
    				msg3ch[3] = "不用充電！";
					break;
			}
			break;
	}
});

app.listen(process.env.PORT || 80, function () {
	console.log('LineBot is running.');
});